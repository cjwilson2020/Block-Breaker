﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoseCollider : MonoBehaviour {

	private LevelManager levelmanager;
	// Use this for initialization

	void OnTriggerEnter2D (Collider2D collider){
		levelmanager = GameObject.FindObjectOfType<LevelManager>();
		levelmanager.LoadLevel ("Lose Screen");
	}

	void OnCollisionEnter2D (Collision2D collision){
		levelmanager = GameObject.FindObjectOfType<LevelManager>();
		levelmanager.LoadLevel ("Lose Screen");
	}
}
