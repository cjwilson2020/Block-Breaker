﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour {
	private Paddle paddle; //to publically expose the paddle in order to access it inside this script

	private Vector3 paddleToBallVector;
	private bool hasStarted = false;


	// Use this for initialization
	void Start () {
		paddle = GameObject.FindObjectOfType<Paddle>();
		paddleToBallVector =  this.transform.position - paddle.transform.position;

	}
	
	// Update is called once per frame
	void Update () {
		


		if (!hasStarted) {
			this.transform.position = paddle.transform.position + paddleToBallVector;
			if (Input.GetMouseButtonDown (0)) {
				print ("Mouse clicked, launch ball");
				hasStarted = true;
				this.GetComponent<Rigidbody2D> ().velocity = new Vector2 (2f, 10f);
			}
		} else {
			/*Vector3 ballPos = new Vector3 (this.transform.position.x, this.transform.position.y, this.transform.position.z);
			float ballPosInBlocks = this.transform.position.x / Screen.width * 16;


			ballPos.x = Mathf.Clamp (ballPosInBlocks, 0.5f, 15.5f);


			float ballYPosInBlocks = this.transform.position.y / Screen.height * 12;


			ballPos.y = Mathf.Clamp (ballPosInBlocks, 0.5f, 11.5f);


			this.transform.position = ballPos; */
		}


	}

	void OnCollisionEnter2D(Collision collision){
		if (hasStarted) {
			audio
			this.GetComponent<AudioSource> ().clip;
		}
	}

}
