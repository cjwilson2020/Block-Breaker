﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class LevelManager : MonoBehaviour {
	private Scene thisScene;


	public void Start(){
		thisScene = SceneManager.GetActiveScene ();
	}
	public void LoadLevel(string name){
		Debug.Log ("New Level load: " + name);
		SceneManager.LoadScene (name, LoadSceneMode.Single);
		//Application.LoadLevel (name);
	}

	public void QuitRequest(){
		Debug.Log ("Quit requested");
		Application.Quit ();
	}

	public void loadNextLevel(){
		SceneManager.LoadScene (thisScene.buildIndex + 1);
	}
}
