﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Brick : MonoBehaviour {
	
	public static int numBricks = 0;
	private int timesHit;
	private LevelManager levelmanager;
	public Sprite[] hitSprites;

	// Use this for initialization
	void Start () {
		bool isBreakable = (this.tag == "Breakable");
		if (isBreakable) {
			numBricks++;
		}
		timesHit = 0;
		levelmanager = GameObject.FindObjectOfType<LevelManager> ();


	}
	
	// Update is called once per frame
	void Update () {
		print (numBricks);
	}

	void OnCollisionEnter2D (Collision2D col){
		bool isBreakable = this.tag == "Breakable";
		if (isBreakable) {
			HandleHits ();
		}
	}
	void HandleHits(){
		timesHit++;
		int maxHits = hitSprites.Length + 1;
		if (timesHit >= maxHits) {
			numBricks--;
			Destroy (gameObject);
		} else {
			LoadSprites ();
		}


		if(numBricks == 0){
			SimulateWin ();
		}
	}

	void LoadSprites(){
		int spriteIndex = timesHit - 1;
		if(hitSprites[spriteIndex]){
			this.GetComponent<SpriteRenderer> ().sprite = hitSprites [spriteIndex];
		}

	}


	// TODO Remove this method once we can actually win
	void SimulateWin(){
		levelmanager.loadNextLevel();
		print ("Win");

	}


}
